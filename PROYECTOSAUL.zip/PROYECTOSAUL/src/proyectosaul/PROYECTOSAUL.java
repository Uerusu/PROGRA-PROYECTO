
package proyectosaul;
import java.util.ArrayList;
import java.util.Scanner;
import java.time.LocalDate;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

public class PROYECTOSAUL {

    static ArrayList<Productos> Inventario = new ArrayList<>();
    static ArrayList<Movimientos> HistorialMovimientos = new ArrayList<>();
    static Scanner entrada = new Scanner(System.in);
    static int opcion;
    static int cantidad;
    static String contra = "Admin123";
    static String usuario = "Admin";
    static String sesion_iniciado;
     static String contraingre;
    
    public static void main(String[] args) {
        Iniciosesion();
        if (sesion_iniciado.equals(usuario) && contraingre.equals(contra)) {
           do { menu(); } while (opcion !=0);}
       
    }
    static void Iniciosesion (){
         sesion_iniciado = JOptionPane.showInputDialog(null, " INGRESE SU USUARIO: ");
        if (sesion_iniciado == null) {
            JOptionPane.showMessageDialog(null, "INICIO CANCELADO");
            System.exit(0);
        }
       contraingre = JOptionPane.showInputDialog(null, " INGRESE LA CONTRASEÑA: ");
        if (contraingre ==null) {
            JOptionPane.showMessageDialog(null, "CONTRASEÑA INCORRECTA");
            System.exit(0);
        }
        if (sesion_iniciado.equals(usuario) && contraingre.equals(contra)) {
            JOptionPane.showMessageDialog(null, "INICIO DE SESION EXITOSO, BIENVENIDO "+sesion_iniciado);
        }
        else{
            JOptionPane.showMessageDialog(null, "USUARIO O CONTRASEÑA INCORRECTOS ");
            System.exit(0);
        }
    }
    
    static void menu (){
        CargadeProductos();
        System.out.println("=====REGISTRO DE SALIDAS E INGRESOS=====");
        System.out.println("1. Registrar ENTRADA de Stock");
        System.out.println("2. Registrar SALIDA de inventario");
        System.out.println("3. Ver ALERTAS de inventario");
        System.out.println("4. Ver historial de movimientos");
        System.out.println("5. Ver estado actual del inventario");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opcion: ");
        opcion = entrada.nextInt();
        switch (opcion){
            case 1: RegistrarEntrada(); break;
            case 2: RegitrarSalida(); break;
            case 3:  break;
            case 4: MostrarHistorial();  break;
            case 5: mostrarProductosPorCategoria(); break;
            case 0: System.out.println("Cerrando Programa"); break;
            }
        }
    //==================================PRODUCTOS QUEMADOS=========================
    public static void CargadeProductos (){
            // Carnes
            Inventario.add(new Productos(1,"Pollo",3500,"Pipasa","Carnes",100));
            Inventario.add(new Productos(2,"Bistek",5000,"Tres J's","Carnes",45));
            Inventario.add(new Productos(3,"Salchichon",3500,"Cinta Azul","Carnes",55));
            Inventario.add(new Productos(4,"Jamon",2500,"FUD","Carnes",80));
            Inventario.add(new Productos(5,"Alitas",3500,"Pipasa","Carnes",75));
            //Lacteos
            Inventario.add(new Productos(6,"Leche",1200,"Dos Pinos","Lacteos",50));
            Inventario.add(new Productos(7,"Yogurt",800,"Yoplait","Lacteos",80));
            Inventario.add(new Productos(8,"Natilla",750,"Zarcero","Lacteos",90));
            Inventario.add(new Productos(9,"Quesocrema",1450,"Dos Pinos","Lacteos",45));
            Inventario.add(new Productos(10,"Mantequilla",650,"Dos Pinos","Lacteos",65));
            Inventario.add(new Productos(11,"Queso",450,"Dos Pinos","Lacteos",120));
            
            //Granos
            Inventario.add(new Productos(12,"Arroz",1100,"Tio Pelon","Granos",120));
            Inventario.add(new Productos(13,"Lentejas",1100,"Tio Pelon","Granos",70));
            Inventario.add(new Productos(14,"Frijoles",1100,"Tio Pelon","Granos",80));
            Inventario.add(new Productos(15,"Garbanzos",1100,"Tio Pelon","Granos",120));
            Inventario.add(new Productos(16,"Mani",1100,"Rumba","Granos",120));
            
            //Limpieza
            Inventario.add(new Productos(17,"Jabon Lavaplatos",1300,"Axion","Limpieza",40));
            Inventario.add(new Productos(18,"Suavitel",2400,"Colgate-Palmolive","Limpieza",30));
            Inventario.add(new Productos(19,"Detergente",2500,"ariel","Limpieza",40));
            Inventario.add(new Productos(20,"Cloro",1100,"Clorox","Limpieza",40));
            Inventario.add(new Productos(21,"Desinfectante",1700,"Fabuloso","Limpieza",40));
            
            //Refrescos
            Inventario.add(new Productos(22,"Pepsi",900,"Pepsi","Refrescos",40));
            Inventario.add(new Productos(23,"Coca Cola",950,"Coca Cola","Refrescos",30));
            Inventario.add(new Productos(24,"Fanta",900,"Dove","Refrescos",35));
            Inventario.add(new Productos(25,"Powerade",900,"Coca Cola","Refrescos",25));
            Inventario.add(new Productos(26,"Jet",1250,"FIFCO","Refrescos",50));
            Inventario.add(new Productos(27,"Monster",1350,"Monster","Refrescos",40));
            Inventario.add(new Productos(28,"RedBull",1300,"Redbull","Refrescos",40));
            Inventario.add(new Productos(29,"Tropical",850,"Tropical","Refrescos",40));
            
            //Verduras por kilo
            Inventario.add(new Productos(30,"Papa",550,"Suli","Verduras",100));
            Inventario.add(new Productos(31,"Tomate",945,"Suli","Verduras",140));
            Inventario.add(new Productos(32,"Yuca",690,"Suli","Verduras",130));
            Inventario.add(new Productos(33,"Pepino",790,"Suli","Verduras",120));
            Inventario.add(new Productos(34,"Cebolla",745,"Suli","Verduras",100));
            Inventario.add(new Productos(35,"Chile",1100,"Suli","Verduras",130));
            Inventario.add(new Productos(36,"Ajo",850,"Suli","Verduras",145));
            
            //Aseo Personal
            Inventario.add(new Productos(37,"Jabon",850,"Dove","Aseo Personal",30));
            Inventario.add(new Productos(38,"Colonia",850,"Jean Paul","Aseo Personal",20));
            Inventario.add(new Productos(39,"Desodorante",850,"Axe","Aseo Personal",20));
            Inventario.add(new Productos(40,"Cepillo Dientes",850,"Colgate","Aseo Personal",30));
            Inventario.add(new Productos(41,"Pasta de Dientes",850,"Colgate","Aseo Personal",40));
            Inventario.add(new Productos(42,"Shampoo",850,"Head&Shoulders","Aseo Personal",40));
    }
    //=============================MOSTRAR PRODUCTOS==============================
    public static void mostrarProductosPorCategoria() {
    // Lista de categorías predefinidas (puedes obtenerla de otra forma si lo prefieres)
    String[] categorias = {"Carnes", "Lacteos", "Granos", "Limpieza", "Refrescos", "Verduras", "Aseo Personal"};
    for (String categoria : categorias) { //Se revisan las categorias hechas en el string
        System.out.println("=== " + categoria + " ===");
        for (int i = 0; i < Inventario.size();i++) {
            Productos p = Inventario.get(i); //Definir una variable "p" para revisar toda la lista 
            if (p.Categoria == categoria) { // Listar todos los datos necesarios
                System.out.println("Codigo: " + p.Codigo + " | " + p.Nombre + " | Marca: " + p.Marca + " | Precio: " + p.Precio + " | Stock: " + p.Stock);
                }
            }
        }
    }
    //===============================ENTRADAS=======================================
    public static void RegistrarEntrada(){
        mostrarProductosPorCategoria();
        System.out.println("Ingrese el codigo del producto que ingresar");
        int codigo = entrada.nextInt();
        System.out.println("Cantidad que desea agregar");
        int cantidad = entrada.nextInt();
        for (Productos p : Inventario) {//Se menciona la lista para poder revisarla
            if (p.Codigo == codigo) { //Se encuentra el codigo del producto digitado
                if (cantidad <= p.Stock) {
                    p.Stock += cantidad; //Se añade al stock
                    //Se guarda el movimiento en el array con class
                    HistorialMovimientos.add(new Movimientos("Entrada",p,cantidad));
                    System.out.println("Entrada registrada para "+ p.Nombre);
                    return;
                }
            }   
        }
    }
    //==============================SALIDAS============================================
    public static void RegitrarSalida(){
        mostrarProductosPorCategoria();
        System.out.println("Ingrese el codigo del producto que retirar");
        int codigo = entrada.nextInt();
        System.out.println("Ingrese la cantidad que desea retirar");
        int cantidad = entrada.nextInt();
        for (Productos p : Inventario) {//Se menciona la lista para poder revisarla
            if (p.Codigo == codigo) {
                if (cantidad <=p.Stock) { //Se revisa que la cantidad que se retira no excesa el stock
                    p.Stock -= cantidad; //Reducimos Stock
                    //Se guarda el movimiento en el historial
                    HistorialMovimientos.add(new Movimientos("Salida",p,cantidad));
                    System.out.println("Salida registrada para"+ p.Nombre);
                }else{
                    System.out.println("Stock Insuficiente");
                }
                return;
            }
        }
    }
    //=================================MOSTRAR HISTORIAL==============================
    public static void MostrarHistorial (){
        System.out.println("=====Historial de Movimiento=====");
        for (Productos m : Inventario) {
            System.out.println(m);
        }
    }
    //==========================ALERTAS INVENTARIO====================================
    public static void ALERTARS (){
        
    }
    //==================================FIN CODIGO====================================
    }

class Productos {
    String Categoria;
    String Nombre; 
    double Precio;
    String Marca;
    int Stock; 
    int Codigo; 
    ArrayList<Integer> CantidadesTotales;
    public Productos (int Codigo, String Nombre,double Precio, String Marca,String Categoria,int Stock) {
        this.Codigo = Codigo;
        this.Nombre = Nombre;
        this.Precio = Precio;
        this.Marca = Marca;
        this.Categoria = Categoria;
        this.Stock = Stock;
        this.CantidadesTotales = new ArrayList<>();
    }
}
class Movimientos {
    String tipo; //Entrada o Salida
    Productos producto;
    int cantidad; 
    String fecha; //Guardar la fecha mediante LocalDate
    
    public Movimientos (String tipo, Productos producto, int cantidad){
        this.tipo = tipo;
        this.producto = producto;
        this.cantidad = cantidad;
        //Guardar fecha
        
        this.fecha = fecha;
        
    }
}
